// JavaScript Document
jQuery(document).ready(function(){
	$('.banner-slider').slick({
		arrows : true,
		prevArrow:'<button type="button" class="slick-prev"></button>',
		nextArrow:'<button type="button" class="slick-next"></button>'
	});
	$('.testimonial-slider').slick({
		arrows : true,
		autoplay : true,
		dots :true,
		prevArrow:'<span class="slick-prev-testi"></span>',
		nextArrow:'<span class="slick-next-testi"></span>'
	});
});